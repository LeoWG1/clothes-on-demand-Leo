package org.example.Model.Products.DesignPatterns;

public interface ProductDecorationCommand {
    void execute();
}
